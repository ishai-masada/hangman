/* Ishai Masada
 * Math Calculations */

#include <iostream>
using namespace std;

int main()
{
    std::cout << "Sum of 15 and 35: ";
    std::cout << 15 + 35 << endl;

    std::cout << "Result of 5 + 10 x 3: ";
    std::cout << 5 + 10 * 3 << endl;

    std::cout << "Result of 5 x 10 + 3: ";
    std::cout << 5 * 10 + 3 << endl;

    std::cout << "Printing out the syntax \"5 * 10 + 3\": ";
    std::cout << "5 * 10 + 3" << endl;

    return 0;
}
